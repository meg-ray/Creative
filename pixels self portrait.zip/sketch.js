var capture;
var stepSize = 5;

function setup() { 
  createCanvas(400, 300);
  capture = createCapture(VIDEO);
  capture.size(400, 300);
  noStroke();
} 

function draw() { 
  background(0);
  stepSize = floor(map(mouseX, 0, width, 5, 20));
  var colorY = map(mouseY, 0, height, 0, 255)
  capture.loadPixels();
  var w = capture.width;
  var h = capture.height;
  for (var y = 0; y < h; y = y + stepSize) {
    for (var x = 0; x < w; x = x + stepSize) {
      var offset = (y * w + x) * 4;
    	var r = capture.pixels[offset];
    	var g = capture.pixels[offset + 1];
    	var b = capture.pixels [offset + 2];
    	var brightness = r / 255;
    	fill(r, g + 100, b + 50);
    	rect(x, y, stepSize * brightness, stepSize * brightness);
  	}
  }  
}
